PORTOFOLIO SALWA NAILA IBRAHIM

BUKA OFFLINE
1. Ekstrak ZIP ini ke satu folder.
2. Buka index.html dengan browser. Foto sudah tertanam di halaman.
   Catatan: tautan email dan LinkedIn memerlukan internet.

PUBLISH GRATIS DENGAN GITHUB PAGES
1. Buat akun GitHub bila belum ada.
2. Buat repository publik baru, misalnya: portofolio-salwa.
3. Unggah file index.html, sw.js, manifest.webmanifest, dan icon.svg ke root repository.
4. Buka Settings > Pages. Pilih Deploy from a branch, branch main, folder /(root), lalu Save.
5. Setelah situs terbit, alamatnya berbentuk:
   https://NAMA-USERNAME.github.io/portofolio-salwa/

Agar situs bisa dibuka offline lewat alamat web, kunjungi sekali saat online dan tunggu
sampai label menunjukkan "Online · offline-ready". Service worker menyimpan halaman agar
bisa dibuka lagi saat offline. Alternatif paling sederhana: simpan file HTML mandiri ini.
Alamat github.io merupakan subdomain; domain pribadi seperti .com dibeli terpisah.

Privasi: periksa kembali informasi kontak sebelum membuat repository publik.
